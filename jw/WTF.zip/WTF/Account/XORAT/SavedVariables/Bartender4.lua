
Bartender4DB = {
	["namespaces"] = {
		["ActionBars"] = {
			["profiles"] = {
				["Krazykim - Bleeding Hollow"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 41.75,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
							["padding"] = 6,
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = -189.4999419734273,
								["x"] = -231.5001850216763,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -82,
								["point"] = "BOTTOMRIGHT",
							},
							["padding"] = 5,
						}, -- [3]
						{
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
							},
							["padding"] = 5,
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 83,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
							["padding"] = 6,
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 83,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
							["padding"] = 6,
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						nil, -- [9]
						{
						}, -- [10]
					},
				},
			},
		},
		["MicroMenu"] = {
			["profiles"] = {
				["Krazykim - Bleeding Hollow"] = {
					["position"] = {
						["y"] = 41.75,
						["x"] = 37.5,
						["point"] = "BOTTOM",
						["scale"] = 1,
					},
					["version"] = 3,
				},
			},
		},
		["XPBar"] = {
		},
		["BlizzardArt"] = {
			["profiles"] = {
				["Krazykim - Bleeding Hollow"] = {
					["enabled"] = true,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
					["version"] = 3,
				},
			},
		},
		["BagBar"] = {
			["profiles"] = {
				["Krazykim - Bleeding Hollow"] = {
					["onebag"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 41.75,
						["x"] = 463.5,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["StanceBar"] = {
			["profiles"] = {
				["Krazykim - Bleeding Hollow"] = {
					["position"] = {
						["y"] = -14.99998926320336,
						["x"] = -82.50003723685188,
						["point"] = "CENTER",
					},
					["version"] = 3,
				},
			},
		},
		["Vehicle"] = {
			["profiles"] = {
				["Krazykim - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 51.49996372056955,
						["x"] = 53.49997862898772,
						["point"] = "CENTER",
					},
				},
			},
		},
		["PetBar"] = {
			["profiles"] = {
				["Krazykim - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 116,
						["x"] = -460,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["RepBar"] = {
		},
	},
	["profileKeys"] = {
		["Krazykim - Bleeding Hollow"] = "Krazykim - Bleeding Hollow",
	},
	["profiles"] = {
		["Krazykim - Bleeding Hollow"] = {
			["focuscastmodifier"] = false,
			["blizzardVehicle"] = true,
			["outofrange"] = "hotkey",
		},
	},
}
