
RecountDB = {
	["profileKeys"] = {
		["Krazykim - Bleeding Hollow"] = "Krazykim - Bleeding Hollow",
	},
	["profiles"] = {
		["Krazykim - Bleeding Hollow"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["h"] = 200.0000027354896,
					["w"] = 140.0000106684094,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["DetailWindowX"] = 0,
			["MainWindowVis"] = false,
			["CurDataSet"] = "OverallData",
			["GraphWindowX"] = 0,
		},
	},
}
