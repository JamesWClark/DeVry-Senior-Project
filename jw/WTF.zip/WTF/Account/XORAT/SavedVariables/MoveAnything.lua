
MADB = {
	["autoShowNext"] = true,
	["frameListRows"] = 18,
	["characters"] = {
	},
	["tooltips"] = true,
	["collapsed"] = true,
	["profiles"] = {
		["default"] = {
			["name"] = "default",
			["frames"] = {
			},
		},
	},
}
