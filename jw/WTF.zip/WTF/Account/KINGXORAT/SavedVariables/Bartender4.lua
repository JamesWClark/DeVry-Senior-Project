
Bartender4DB = {
	["namespaces"] = {
		["ActionBars"] = {
			["profiles"] = {
				["Lanival - Bleeding Hollow"] = {
					["actionbars"] = {
						{
							["version"] = 3,
							["position"] = {
								["y"] = 187.9999833135136,
								["x"] = -211.7861024956487,
								["point"] = "BOTTOM",
							},
							["rows"] = 2,
							["padding"] = 1,
							["states"] = {
								["stance"] = {
									["WARRIOR"] = {
										["berserker"] = 3,
										["battle"] = 1,
										["def"] = 2,
									},
								},
							},
						}, -- [1]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 112.0000032825875,
								["x"] = -211.7859624385824,
								["point"] = "BOTTOM",
							},
							["rows"] = 2,
							["padding"] = 1,
							["states"] = {
								["enabled"] = true,
								["stance"] = {
									["WARRIOR"] = {
										["berserker"] = 6,
										["battle"] = 4,
										["def"] = 5,
									},
								},
							},
						}, -- [2]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 187.9999833135136,
								["x"] = -435.7860915536903,
								["point"] = "BOTTOM",
							},
							["rows"] = 2,
							["padding"] = 1,
							["states"] = {
								["enabled"] = true,
								["stance"] = {
									["WARRIOR"] = {
										["berserker"] = 9,
										["battle"] = 7,
										["def"] = 8,
									},
								},
							},
						}, -- [3]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
							},
							["rows"] = 12,
							["padding"] = 5,
						}, -- [4]
						{
							["enabled"] = false,
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 83,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["enabled"] = false,
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 83,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						nil, -- [9]
						{
							["enabled"] = true,
							["version"] = 3,
							["position"] = {
								["y"] = 112.0000032825875,
								["x"] = -435.7860915536903,
								["point"] = "BOTTOM",
							},
							["rows"] = 2,
							["padding"] = 1,
						}, -- [10]
					},
				},
				["Xorat - Bleeding Hollow"] = {
					["actionbars"] = {
						{
							["rows"] = 2,
							["version"] = 3,
							["position"] = {
								["y"] = 198.4999915541759,
								["x"] = -235.0732508715441,
								["point"] = "BOTTOM",
							},
							["padding"] = 1,
						}, -- [1]
						{
							["rows"] = 2,
							["version"] = 3,
							["position"] = {
								["y"] = 122.5000027696832,
								["x"] = -235.0732508715441,
								["point"] = "BOTTOM",
							},
							["padding"] = 1,
						}, -- [2]
						{
							["rows"] = 2,
							["version"] = 3,
							["position"] = {
								["y"] = 198.4999915541759,
								["x"] = -459.0731699010526,
								["point"] = "BOTTOM",
							},
							["padding"] = 1,
						}, -- [3]
						{
							["rows"] = 2,
							["version"] = 3,
							["position"] = {
								["y"] = 122.5000027696832,
								["x"] = -459.6304919825878,
								["point"] = "BOTTOM",
							},
							["padding"] = 1,
						}, -- [4]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 41.49999859806159,
								["x"] = -457.0731549926344,
								["point"] = "BOTTOM",
							},
							["padding"] = 1,
						}, -- [5]
						{
							["version"] = 3,
							["position"] = {
								["y"] = 43.99999972645104,
								["x"] = -10.74349745062636,
								["point"] = "BOTTOM",
							},
							["padding"] = 1,
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						nil, -- [9]
						{
						}, -- [10]
					},
				},
				["Mizzouri - Bleeding Hollow"] = {
					["actionbars"] = {
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 41.75,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = -189.4999419734273,
								["x"] = -231.5001850216763,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -82,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [3]
						{
							["padding"] = 5,
							["rows"] = 12,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [4]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 83,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 83,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						nil, -- [9]
						{
						}, -- [10]
					},
				},
				["Tetrazine - Bleeding Hollow"] = {
					["actionbars"] = {
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 41.75,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [1]
						{
							["enabled"] = false,
							["version"] = 3,
							["position"] = {
								["y"] = -189.4999419734273,
								["x"] = -231.5001850216763,
								["point"] = "CENTER",
							},
						}, -- [2]
						{
							["rows"] = 12,
							["padding"] = 5,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -82,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [3]
						{
							["rows"] = 12,
							["padding"] = 5,
							["version"] = 3,
							["position"] = {
								["y"] = 610,
								["x"] = -42,
								["point"] = "BOTTOMRIGHT",
							},
						}, -- [4]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 83,
								["x"] = 3,
								["point"] = "BOTTOM",
							},
						}, -- [5]
						{
							["padding"] = 6,
							["version"] = 3,
							["position"] = {
								["y"] = 83,
								["x"] = -510,
								["point"] = "BOTTOM",
							},
						}, -- [6]
						{
						}, -- [7]
						{
						}, -- [8]
						nil, -- [9]
						{
						}, -- [10]
					},
				},
			},
		},
		["MicroMenu"] = {
			["profiles"] = {
				["Lanival - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 40.50000865098579,
						["x"] = 12.55583589004732,
						["point"] = "BOTTOM",
						["scale"] = 1,
					},
				},
				["Xorat - Bleeding Hollow"] = {
					["position"] = {
						["y"] = 40.50000865098579,
						["x"] = -432.3201693596309,
						["point"] = "BOTTOMRIGHT",
						["scale"] = 1,
					},
					["version"] = 3,
				},
				["Mizzouri - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 41.75,
						["x"] = 37.5,
						["point"] = "BOTTOM",
						["scale"] = 1,
					},
				},
				["Tetrazine - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 41.75,
						["x"] = 37.5,
						["point"] = "BOTTOM",
						["scale"] = 1,
					},
				},
			},
		},
		["XPBar"] = {
			["profiles"] = {
				["Xorat - Bleeding Hollow"] = {
					["position"] = {
						["y"] = -203.3110743354931,
						["x"] = -31.54442281204092,
						["point"] = "CENTER",
					},
					["version"] = 3,
				},
				["Lanival - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 10.00003952782447,
						["x"] = 443.9998782707137,
						["point"] = "LEFT",
					},
				},
			},
		},
		["BlizzardArt"] = {
			["profiles"] = {
				["Lanival - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
				},
				["Xorat - Bleeding Hollow"] = {
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
					["version"] = 3,
				},
				["Mizzouri - Bleeding Hollow"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
				},
				["Tetrazine - Bleeding Hollow"] = {
					["enabled"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 47,
						["x"] = -512,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["BagBar"] = {
			["profiles"] = {
				["Lanival - Bleeding Hollow"] = {
					["onebag"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 40,
						["x"] = 268.7041038019818,
						["point"] = "BOTTOM",
					},
				},
				["Xorat - Bleeding Hollow"] = {
					["onebag"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 36.00000136774479,
						["x"] = -469.0526560543806,
						["point"] = "BOTTOMRIGHT",
					},
					["padding"] = 1,
				},
				["Mizzouri - Bleeding Hollow"] = {
					["onebag"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 41.75,
						["x"] = 463.5,
						["point"] = "BOTTOM",
					},
				},
				["Tetrazine - Bleeding Hollow"] = {
					["onebag"] = true,
					["version"] = 3,
					["position"] = {
						["y"] = 41.75,
						["x"] = 463.5,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["Vehicle"] = {
			["profiles"] = {
				["Lanival - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 51.49996372056955,
						["x"] = 53.49997862898772,
						["point"] = "CENTER",
					},
				},
				["Xorat - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 51.49996372056955,
						["x"] = 53.49997862898772,
						["point"] = "CENTER",
					},
				},
				["Mizzouri - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 51.49996372056955,
						["x"] = 53.49997862898772,
						["point"] = "CENTER",
					},
				},
				["Tetrazine - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 51.49996372056955,
						["x"] = 53.49997862898772,
						["point"] = "CENTER",
					},
				},
			},
		},
		["StanceBar"] = {
			["profiles"] = {
				["Lanival - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 36.00000136774479,
						["x"] = -406.2912638515788,
						["point"] = "BOTTOM",
						["scale"] = 1,
					},
				},
				["Xorat - Bleeding Hollow"] = {
					["position"] = {
						["y"] = 232.5000174045524,
						["x"] = -44.07322768826998,
						["point"] = "BOTTOM",
						["scale"] = 1,
					},
					["version"] = 3,
				},
				["Mizzouri - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -14.99998926320336,
						["x"] = -82.50003723685188,
						["point"] = "CENTER",
					},
				},
				["Tetrazine - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = -14.99998926320336,
						["x"] = -82.50003723685188,
						["point"] = "CENTER",
					},
				},
			},
		},
		["PetBar"] = {
			["profiles"] = {
				["Lanival - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 36.00000136774479,
						["x"] = -309.2330473675324,
						["point"] = "BOTTOM",
					},
				},
				["Xorat - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 232.5000174045524,
						["x"] = -376.7518980023472,
						["point"] = "BOTTOM",
					},
				},
				["Mizzouri - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 116,
						["x"] = -460,
						["point"] = "BOTTOM",
					},
				},
				["Tetrazine - Bleeding Hollow"] = {
					["version"] = 3,
					["position"] = {
						["y"] = 116,
						["x"] = -460,
						["point"] = "BOTTOM",
					},
				},
			},
		},
		["RepBar"] = {
			["profiles"] = {
				["Xorat - Bleeding Hollow"] = {
					["enabled"] = true,
					["position"] = {
						["y"] = 54.00000551041953,
						["x"] = -6.571481687506775,
						["point"] = "BOTTOM",
						["scale"] = 0.6000000238418579,
					},
					["version"] = 3,
				},
			},
		},
	},
	["profileKeys"] = {
		["Lanival - Bleeding Hollow"] = "Lanival - Bleeding Hollow",
		["Xorat - Bleeding Hollow"] = "Xorat - Bleeding Hollow",
		["Mizzouri - Bleeding Hollow"] = "Mizzouri - Bleeding Hollow",
		["Tetrazine - Bleeding Hollow"] = "Tetrazine - Bleeding Hollow",
	},
	["profiles"] = {
		["Lanival - Bleeding Hollow"] = {
			["focuscastmodifier"] = false,
			["blizzardVehicle"] = true,
			["minimapIcon"] = {
				["minimapPos"] = 195.4221705910957,
			},
			["outofrange"] = "hotkey",
		},
		["Xorat - Bleeding Hollow"] = {
			["blizzardVehicle"] = true,
			["focuscastmodifier"] = false,
			["minimapIcon"] = {
				["minimapPos"] = 192.0947821000632,
			},
			["outofrange"] = "hotkey",
		},
		["Mizzouri - Bleeding Hollow"] = {
			["focuscastmodifier"] = false,
			["blizzardVehicle"] = true,
			["outofrange"] = "hotkey",
		},
		["Tetrazine - Bleeding Hollow"] = {
			["focuscastmodifier"] = false,
			["blizzardVehicle"] = true,
			["minimapIcon"] = {
				["minimapPos"] = 345.4889366542352,
			},
			["outofrange"] = "hotkey",
		},
	},
}
