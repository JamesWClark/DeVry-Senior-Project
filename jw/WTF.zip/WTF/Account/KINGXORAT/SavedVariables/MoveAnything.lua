
MADB = {
	["frameListRows"] = 18,
	["characters"] = {
	},
	["tooltips"] = 1,
	["collapsed"] = true,
	["profiles"] = {
		["default"] = {
			["name"] = "default",
			["frames"] = {
				["ReputationWatchBar"] = {
					["orgHeight"] = 11.00000102580859,
					["name"] = "ReputationWatchBar",
					["height"] = 11.00001634455023,
					["orgWidth"] = 1024,
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"UIParent", -- [2]
						"BOTTOMLEFT", -- [3]
						0.9999724399424974, -- [4]
						-1.500470743562829, -- [5]
					},
					["width"] = 554.0000329626495,
				},
				["BattlefieldMinimap"] = {
					["scale"] = 1.293332334259578,
					["name"] = "BattlefieldMinimap",
					["pos"] = {
						"TOPLEFT", -- [1]
						"BattlefieldMinimapTab", -- [2]
						"BOTTOMLEFT", -- [3]
						13.91731349328368, -- [4]
						-43.29911753501007, -- [5]
					},
				},
				["FramerateLabel"] = {
					["name"] = "FramerateLabel",
					["pos"] = {
						"BOTTOMLEFT", -- [1]
						"UIParent", -- [2]
						"BOTTOMLEFT", -- [3]
						12.80000787820999, -- [4]
						667.7111396863392, -- [5]
					},
				},
				["CastingBarFrame"] = {
					["name"] = "CastingBarFrame",
					["pos"] = {
						"BOTTOM", -- [1]
						"UIParent", -- [2]
						"BOTTOM", -- [3]
						0, -- [4]
						227.9999663534782, -- [5]
					},
				},
				["VehicleMenuBarLeaveButton"] = {
					["name"] = "VehicleMenuBarLeaveButton",
					["pos"] = {
						"BOTTOMRIGHT", -- [1]
						"VehicleMenuBar", -- [2]
						"BOTTOMRIGHT", -- [3]
						165.0005296591696, -- [4]
						123.4998504713009, -- [5]
					},
				},
			},
		},
	},
}
