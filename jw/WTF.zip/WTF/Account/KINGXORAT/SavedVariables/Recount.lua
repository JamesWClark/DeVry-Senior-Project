
RecountDB = {
	["profileKeys"] = {
		["Lanival - Bleeding Hollow"] = "Lanival - Bleeding Hollow",
		["Xorat - Bleeding Hollow"] = "Xorat - Bleeding Hollow",
		["Mizzouri - Bleeding Hollow"] = "Mizzouri - Bleeding Hollow",
		["Tetrazine - Bleeding Hollow"] = "Tetrazine - Bleeding Hollow",
	},
	["profiles"] = {
		["Lanival - Bleeding Hollow"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -431.4998551216332,
					["h"] = 196.999962865729,
					["w"] = 400.0000054709792,
					["x"] = -629.9998379222425,
				},
			},
			["DetailWindowX"] = 0,
			["LastInstanceName"] = "Strand of the Ancients",
			["CurDataSet"] = "OverallData",
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["MainWindowHeight"] = 196.999962865729,
			["MainWindowWidth"] = 400.0000054709792,
			["GraphWindowX"] = 0,
		},
		["Xorat - Bleeding Hollow"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = -426.0002342946824,
					["h"] = 204.0000150451927,
					["w"] = 387.9999510347366,
					["x"] = -644.0003274381025,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["DetailWindowX"] = 0,
			["LastInstanceName"] = "Dalaran Sewers",
			["CurDataSet"] = "OverallData",
			["GraphWindowX"] = 0,
			["MainWindowWidth"] = 387.9999160204699,
			["MainWindowHeight"] = 204.0000150451927,
		},
		["Mizzouri - Bleeding Hollow"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["y"] = 43.99997784253441,
					["h"] = 199.9999852283563,
					["w"] = 140.0000106684094,
					["x"] = -860.0000205161718,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["CurDataSet"] = "OverallData",
			["GraphWindowX"] = 0,
			["DetailWindowX"] = 0,
		},
		["Tetrazine - Bleeding Hollow"] = {
			["GraphWindowY"] = 0,
			["MainWindow"] = {
				["Position"] = {
					["w"] = 140.0000106684094,
					["h"] = 200.0000027354896,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
				},
			},
			["DetailWindowY"] = 0,
			["DetailWindowX"] = 0,
			["MainWindowVis"] = false,
			["CurDataSet"] = "OverallData",
			["GraphWindowX"] = 0,
		},
	},
}
