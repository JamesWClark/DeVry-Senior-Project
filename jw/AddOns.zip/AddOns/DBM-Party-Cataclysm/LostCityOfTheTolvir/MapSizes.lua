DBM:RegisterMapSize("LostCityofTolvir", 
	0, 970.833251953125, 647.9169921875
)
